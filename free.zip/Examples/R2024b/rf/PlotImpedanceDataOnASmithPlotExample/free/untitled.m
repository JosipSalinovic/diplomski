% Sample reflection coefficient data
Gamma1 = [0.2 + 0.3j, 0.4 + 0.1j];
Gamma2 = [0.1 - 0.2j, 0.3 - 0.4j];

% Plot Smith chart
figure;
h = smithchart;
hold on;

% Plot data with DisplayName for legend
plot(h, Gamma1, 'r-o', 'DisplayName', 'Dataset 1');
plot(h, Gamma2, 'b-s', 'DisplayName', 'Dataset 2');

% Add legend
legend('show');
title('Smith Chart with Legend');
